# Define variables of different data types
a_string = "Hello, World!"
a_float = 3.14
an_integer = 42

# Display the data types using the type() function
print(f"The data type of '{a_string}' is {type(a_string)}")
print(f"The data type of {a_float} is {type(a_float)}")
print(f"The data type of {an_integer} is {type(an_integer)}")
