# Compute the product of 10, 100, 1000, and 10000
result = 10 * 100 * 1000 * 10000

# Display the result
print(result)
