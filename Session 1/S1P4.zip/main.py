# Prompt the user to enter two floating-point numbers
num1 = float(input("Enter the first floating-point number: "))
num2 = float(input("Enter the second floating-point number: "))

# Calculate and display the product
product = num1 * num2
print(f"The product of {num1} and {num2} is {product}")
