# Display the numerical values of True and False
print(f"True as an integer: {int(True)}")
print(f"False as an integer: {int(False)}")
