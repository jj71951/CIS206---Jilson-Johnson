import xml.etree.ElementTree as ET

# Load XML data
tree = ET.parse('books.xml')
root = tree.getroot()

# Convert XML data to a list of dictionaries
books = []
for book in root.findall('book'):
    books.append({
        'title': book.find('title').text,
        'author': book.find('author').text,
        'year': int(book.find('year').text)
    })

# Display all books
print("Books Available:")
for book in books:
    print(f"- {book['title']} by {book['author']} ({book['year']})")

# Search for a book
while True:
    search_title = input("\nEnter a book title to search (or type 'exit' to quit): ").strip()
    if search_title.lower() == 'exit':
        break
    found = next((book for book in books if book['title'].lower() == search_title.lower()), None)
    if found:
        print(f"\nFound: {found['title']} by {found['author']} ({found['year']})")
    else:
        print(f"\n'{search_title}' not found.")
