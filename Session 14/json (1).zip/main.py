import json

# Load JSON data
with open('books.json', 'r') as file:
    books = json.load(file)

# Display all books
print("Books Available:")
for book in books:
    print(f"- {book['title']} by {book['author']} ({book['year']})")

# Search for a book
while True:
    search_title = input("\nEnter a book title to search (or type 'exit' to quit): ").strip()
    if search_title.lower() == 'exit':
        break
    found = next((book for book in books if book['title'].lower() == search_title.lower()), None)
    if found:
        print(f"\nFound: {found['title']} by {found['author']} ({found['year']})")
    else:
        print(f"\n'{search_title}' not found.")
